package com.example.gradeportal;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DBNAME="IDU.DB";
    public static final String TABLE_NAME="IDU";

    public static final String COLS_1="username";
    public static final String COLS_2="subject";
    public static final String COLS_3="grade";
    public DatabaseHelper(Context context) {
        super(context, DBNAME, null , 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create Table TABLE_NAME(username TEXT  primary key, subject TEXT, grade TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists TABLE_NAME");
    }



}

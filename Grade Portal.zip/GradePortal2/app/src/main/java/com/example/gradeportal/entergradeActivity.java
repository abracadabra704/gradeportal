package com.example.gradeportal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class entergradeActivity extends AppCompatActivity {
    Button insert, update;
    EditText username,  grade;
    DBHelper DB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entergrade);

      username=(EditText)findViewById(R.id.txtusername);

      grade=(EditText)findViewById(R.id.txtgrade);
        insert=(Button) findViewById(R.id.btninsert);
        update=(Button) findViewById(R.id.btnupdate);
        DB= new DBHelper(this);

        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString();
                String grades = grade.getText().toString();

                if(user.equals("")|| grades.equals(""))
                    Toast.makeText(entergradeActivity.this, "Please enter all the fields", Toast.LENGTH_SHORT).show();
                else{
                        boolean checkuser= DB.checkusername(user);
                        if (checkuser==true){
                            Boolean insert = DB.insertgrade(grades);
                            if (insert==true){
                                Toast.makeText(entergradeActivity.this, "Saved", Toast.LENGTH_SHORT).show();

                            }

                        }
                        else {
                            Toast.makeText(entergradeActivity.this, "User doesn't exist", Toast.LENGTH_SHORT).show();
                        }



                }
            }
        });

    }

}